// Name: Matthew Zaldana
// CECS 282-05
// Program 03 - Student Structs
// March 09, 2021
// I certify that this program is my own original work. I did not copy any part of his program from any other source. I further certify that I typed each and every line of code in this program.


// Imports all necessary libraries
#include <stdio.h>
#include <iostream>
#include <iomanip>
#include <string.h>
#include <cstdlib>
#include <cstring>
#include <math.h>
#include <sstream>
using namespace std;


// Defines MYDATE
#ifndef MYDATE_H
#define MYDATE_H
#include <iostream>
#include <string>
using namespace std;

// myDate class imported from last assignment
class myDate {
    int month;
    int day;
    int year;
	public:
		myDate();
		myDate(int, int, int);
		void constructor();
		void display();
		void increaseDate(int);
		void decreaseDate(int);
		int daysBetween(myDate D);
		int getMonth();
		int getDay();
		int getYear();
		int dayOfYear();
		string dayName();
		void random();
		string toString();
	private:
		int JD;
};
#endif

// Student structure for program
struct Student {
   char name[20];
   int id;
   char grade;
   myDate bday;
   string homeTown;
};

// Header functions
void populateStudents(Student *students[]);
void sortName(Student *students[]);
void sortID(Student *students[]);
void sortGrade(Student *students[]);
void sortBday(Student *students[]);
void sortTown(Student *students[]);


// Main function
int main()
{
	// Student pointer
	Student *students[10];
   	populateStudents(students);

	// If not exiting
	while (true) {
		cout << setw(20) << left << "Name";
		cout << setw(13) << left << "Student ID";
		cout << setw(10) << left << "Grade";
		cout << setw(20) << left << "Birthday";
		cout << setw(10) << left << "Home Town" << endl;

		for (int i = 0; i < 10; i++) {
			cout << setw(20) << left << students[i]->name;
			cout << setw(13) << left << students[i]->id;
			cout << setw(10) << left << students[i]->grade;
			cout << setw(20) << left << students[i]->bday.toString();
			cout << setw(10) << left << students[i]->homeTown << endl;
		}

		cout<< "1) Display list sorted by Name\n"
			<< "2) Display list sorted by Student ID\n"
			<< "3) Display list sorted by Grade\n"
			<< "4) Display list sorted by Birthday\n"
			<< "5) Display list sorted by Home Town\n"
			<< "6) Exit\n";
		
		int i;
		cin >> i;

		switch (i) {
			case 1:
				sortName(students);
				break;
			case 2:
				sortID(students);
				break;
			case 3:
				sortGrade(students);
				break;
			case 4:
				sortBday(students);
				break;
			case 5:
				sortTown(students);
				break;
			case 6:
				exit(0);

			default:
				cout << "Invalid input";
				break;
		}
	}
	return 0;
}

// Makes grades, neames, and towns, with grades and birthdays randomly
void populateStudents(Student *students[]) {
	char grades[] = { 'A', 'B', 'C', 'D', 'F' };
	string names[] = { "Tom Thumb", "Fred Flintstone", "Sponge Bob", "James Bond", "Kobe Bryant", "Bill Gates", "Elon Musk", "Joe Biden", "Jeff Bezos", "Boolean Legend" };
	string towns[] = { "Small Ville", "Bedrock", "Bikini Bottom", "Zurich", "Philadelphia", "Seattle", "Pretoria", "Scranton", "Albuquerque", "Los Angeles" };

	for (int i = 0; i < 10; i++) {
		students[i] = new Student;

		strcpy(students[i]->name, names[i].c_str());
		students[i]->id = rand() % 8999 + 1000;
		students[i]->grade = grades[rand() % 5];

		students[i]->bday = myDate();
		students[i]->bday.random();

		students[i]->homeTown = towns[i];
	}
}


// Sort students by first names
void sortName(Student *students[]) {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            if (strcmp(students[i]->name, students[j]->name) < 0) {
				Student *temp = students[i];
                students[i] = students[j];
                students[j] = temp;
			}
		}
	}
}


// Sorts students by ID number
void sortID(Student *students[]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (students[i]->id < students[j]->id) {
				Student *temp = students[i];
				students[i] = students[j];
				students[j] = temp;
			}
		}
	}
}


// Sorts students by grades
void sortGrade(Student *students[]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (students[i]->grade < students[j]->grade) {
				Student *temp = students[i];
				students[i] = students[j];
				students[j] = temp;
			}
		}
	}
}


// Sorts students by birthday
void sortBday(Student *students[]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (students[i]->bday.daysBetween(students[j]->bday) > 0) {
				Student *temp = students[i];
				students[i] = students[j];
				students[j] = temp;
			}
		}
	}
}


// Sorts students by town name
void sortTown(Student *students[]) {
	for (int i = 0; i < 10; i++) {
		for (int j = 0; j < 10; j++) {
			if (students[i]->homeTown.compare(students[j]->homeTown) < 0) {
				Student *temp = students[i];
				students[i] = students[j];
				students[j] = temp;
			}
		}
	}
}


// Class constructor
myDate::myDate() {
	month = 5;
    day = 11;
    year = 1959;
}


// Overloaded constructor with date
myDate::myDate(int M, int D, int Y){
	if ((M >0 && M <13) && (D > 0 && D < 32)) {
    	month = M;
        day = D;
        year = Y;
    } else
		myDate();
    
}


// instance variable constructor
void myDate::constructor() {
	month = 5;
    day = 11;
    year = 1959;
}


// Greg to Julian converter
int Greg2Julian(int month, int day, int year) {
	double a = (month + 9) / 12;
    int intA = a;
    double b = 7 * (year + intA) / 4;
    int intB = b;
    double c = (275 * month) / 9;
    int intC = c;
      
    double UT = 12 / 24;
    double doublesin = 0.5 * sin(100 * year + month - 19002.5);
    double roundUT = round(UT + doublesin);
    int intUT = roundUT;
      
      
    int JD = 367 * year - intB + intC + day + 1721013.5 + intUT + 0.5;
    return JD;
}


// Julian to Greg converter
void Julian2Greg(int JD, int &month, int &day, int &year) {
    int p, q, r, s, t, u, v;
    p = JD + 68569;
    q = 4 * p / 146097;
    r = p - (146097 * q + 3) / 4;
    s = 4000 * (r + 1) / 1461001;
    t = r - 1461 * s / 4 + 31;
    u = 80 * t / 2447;
    v = u / 11;
      
    year = 100 * (q - 49) + s + v;
    month = u + 2 - 12 * v;
    day = t - 2447 * u / 80;
}


// Displays date
void myDate::display() {
    string monthString;
    if (month == 1)
        monthString = "January";
    else if (month == 2)
        monthString = "Febuary";
    else if (month ==3)
        monthString = "March";
    else if (month == 4)
        monthString = "April";
    else if (month == 5)
        monthString = "May";
    else if (month == 6)
        monthString = "June";
    else if (month == 7)
        monthString = "July";
    else if (month == 8)
        monthString = "August";
    else if (month == 9)
        monthString = "September";
    else if (month == 10)
        monthString = "October";
    else if (month == 11)
        monthString = "Nobember";
    else if (month == 12)
        monthString = "December";
    else
        myDate();
    cout << monthString << " " << day << ", " << year;
}


// Adds a date
void myDate::increaseDate(int N){
    int JD = Greg2Julian(month, day, year);
    JD += N;
    Julian2Greg(JD, month, day, year);
}


// Subtracts a date
void myDate::decreaseDate(int N){
    int JD = Greg2Julian(month, day, year);
    JD -= N;
    Julian2Greg(JD, month, day, year);
}


// Returns amount of days between two dates
int myDate::daysBetween(myDate D) {
   JD = Greg2Julian(month, day, year);
   return Greg2Julian(D.month, D.day, D.year) - JD;
}


// Returns the month
int myDate::getMonth() {
    return month;
}


// Returns the day
int myDate::getDay() {
    return day;
}


// Returns the year
int myDate::getYear() {
    return year;
}


// Returns the day of the year given leap and nonleap year month days
int myDate::dayOfYear() {
    int leap[] = {0,31,28,31,30,31,30,31,31,30,31,30,31};
    int nonLeap[] = {0,31,29,31,30,31,30,31,31,30,31,30,31};
    int theDayOfYear = 0;
      
    
    if (((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0)) {
    	for (int x = 0; x < month; x++) {
    		theDayOfYear += nonLeap[x];
		}
	} else {
    	for(int x = 0; x<month;x++){
        	theDayOfYear += leap[x];
    	}
    	theDayOfYear += day;
	}
    return theDayOfYear;
}


// Returns the name of the day
string myDate::dayName() {
	int JD = Greg2Julian(month, day, year);
	if (JD % 7 == 0)
        return "Monday";
    else if (JD % 7 == 1)
        return "Tuesday";
    else if (JD % 7 == 2)
        return "Wednesday";
    else if (JD % 7 == 3)
        return "Thursday";
    else if (JD % 7 == 4)
        return "Friday";
    else if (JD % 7 == 5)
        return "Saturday";
    else
        return "Sunday";
}


// Randomizes a date
void myDate::random() {
	myDate start = myDate(01, 01, 2000);
	myDate end = myDate(12, 31, 2005);
	int JD = (rand() % start.daysBetween(end)) + start.JD;
	Julian2Greg(JD, month, day, year);
}


// Returns date in Month, Day, Year format
string myDate::toString() {
	string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	stringstream buffer;
	buffer << months[month - 1] << " " << day << ", " << year;
	return buffer.str();
}